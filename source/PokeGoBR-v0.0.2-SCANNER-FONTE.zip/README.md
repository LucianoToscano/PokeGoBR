# PokeGoBR — Android (v0.0.2, Scanner MVP)

Código Android próprio, preservando projetos originais PokeSearch e PvPPokeGo. UI com as artes fornecidas pelo responsável do PokeGoBR.

## Primeiro scanner funcional
- Entradas **Meus Pokémon**, **Busca** e **Raides** abrem o módulo Scanner.
- Seleção de captura de tela pela galeria do Android (sem solicitar acesso contínuo às fotos).
- Reconhecimento OCR **on-device** via ML Kit Text Recognition 16.0.1.
- Extração heurística de PC/CP e PS/HP; revisão manual de nome, valores e IV.
- Cálculo fiel apenas **quando os 3 valores de IV são informados** pelo usuário; sem inventar IV a partir de CP.
- Suporte inicial a leitura textual de capturas de raides. **Não** cria lobbies nem entra automaticamente em raides.
- Registro local dos últimos scans no `SharedPreferences` (dados editados, não inclui imagens).

## Compilar
Requisitos JDK 17 e Android SDK 35.
```
./gradlew :app:assembleDebug
```
APK `app/build/outputs/apk/debug/app-debug.apk`.
GitHub Actions `.github/workflows/android-debug.yml` automatiza o build de QA em novo push.

## Segurança e limites
- Sem ROOT, Accessibility, GPS falso ou injeção no jogo.
- Sem rede própria e sem envio de imagens; ML Kit bundled executa o OCR no dispositivo.
- Screenshot de avaliação: barras de IV **não** são lidas automaticamente nesta versão.
- Pokémon GO e nomes de espécies pertencem aos respectivos titulares; respeitar direitos e políticas do jogo.
- APK debug utiliza assinatura debug do runner, não a chave de distribuição definitiva.

## Roadmap
1. QA em aparelhos reais, correção da extração OCR em capturas PT-BR.
2. Detectar barras de avaliação do Pokémon com calibração + testes de referência.
3. Game Master versionado e cálculo de nível/CP/IV possíveis.
4. Raides: reconhecimento do chefe, tier e tempo; convites e agendamento comunitário opcionais.
5. Overlay mediante consentimento e revisão de políticas Android.
