# Changelog
## 0.0.2 — 2026-11-02
- Fundação Android Kotlin/Compose com 11 menus fiéis às artes originais.
- Topo compacto: Mewtwo, Charizard e marca PokeGoBR, individualmente renderizados sem distorcer.
- Fundo separado e contínuo; ícone selecionado com brilho independentemente da aba Home.
- Scanner inicial: captura de imagem pelo seletor Android, OCR ML Kit offline, leitura PC/PS e revisão manual do IV.
- Histórico mínimo no aparelho; scanner de raides em modo leitura.
- GitHub Actions build debug para teste; nenhuma integração proprietária embutida.
