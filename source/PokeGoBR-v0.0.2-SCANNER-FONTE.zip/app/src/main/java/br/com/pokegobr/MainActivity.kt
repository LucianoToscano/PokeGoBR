package br.com.pokegobr

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { PokeGoBRRoot() }
    }
}

private data class AppModule(val title: String, val drawable: Int, val screen: Screen)
private enum class Screen { HOME, SCANNER_POKEMON, SCANNER_RAID, OTHER }
private val cyan = Color(0xFF36E6FF)
private val ice = Color(0xFFEAF8FF)
private val modules = listOf(
    AppModule("Home", R.drawable.menu_home, Screen.HOME),
    AppModule("Meus Pokémon", R.drawable.menu_pokemon, Screen.SCANNER_POKEMON),
    AppModule("Pokédex", R.drawable.menu_pokedex, Screen.OTHER),
    AppModule("Raides", R.drawable.menu_raides, Screen.SCANNER_RAID),
    AppModule("Trocas", R.drawable.menu_trocas, Screen.OTHER),
    AppModule("PvP", R.drawable.menu_pvp, Screen.OTHER),
    AppModule("Itens", R.drawable.menu_itens, Screen.OTHER),
    AppModule("Comunidade", R.drawable.menu_comunidade, Screen.OTHER),
    AppModule("Scanner", R.drawable.menu_scanner, Screen.SCANNER_POKEMON),
    AppModule("Calculadoras", R.drawable.menu_calculadora, Screen.OTHER),
    AppModule("Extras", R.drawable.menu_extra, Screen.OTHER)
)

@Composable
private fun PokeGoBRRoot() {
    var selected by rememberSaveable { mutableIntStateOf(0) }
    var showMenu by remember { mutableStateOf(false) }
    val selectedModule = modules[selected]

    MaterialTheme(colorScheme = darkColorScheme(primary = cyan, surface = Color(0xFF113B62))) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val screenWidth = maxWidth
            val screenHeight = maxHeight
            Image(
                painter = painterResource(R.drawable.landscape),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alignment = Alignment.BottomCenter
            )
            // Keeps the landscape visible, while visually blending its sky into the battle header.
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
                0f to Color(0xFF031331).copy(alpha = .10f),
                .30f to Color(0xFF0A4F88).copy(alpha = .06f),
                1f to Color.Transparent
            )))
            Column(
                modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Hero illustration uses the ORIGINAL individual graphics, not a flattened image with fake buttons.
                val heroHeight = (screenHeight * .12f).coerceIn(78.dp, 120.dp)
                Box(Modifier.fillMaxWidth().height(heroHeight)) {
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
                        listOf(Color(0xFF09113B).copy(alpha = .84f), Color(0xFF0B4084).copy(alpha = .52f), Color.Transparent)
                    )))
                    Image(
                        painter = painterResource(R.drawable.hero_mewtwo),
                        contentDescription = "Mewtwo usando poder psíquico",
                        contentScale = ContentScale.Fit,
                        alignment = Alignment.CenterStart,
                        modifier = Modifier.align(Alignment.CenterStart)
                            .width(screenWidth * .42f).height(heroHeight)
                    )
                    Image(
                        painter = painterResource(R.drawable.hero_charizard),
                        contentDescription = "Charizard usando poder de fogo",
                        contentScale = ContentScale.Fit,
                        alignment = Alignment.CenterEnd,
                        modifier = Modifier.align(Alignment.CenterEnd)
                            .width(screenWidth * .44f).height(heroHeight)
                    )
                    Image(
                        painter = painterResource(R.drawable.hero_logo),
                        contentDescription = "Logo original PokeGoBR",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.align(Alignment.Center).width(screenWidth * .51f).height(heroHeight * .86f)
                    )
                    Box(Modifier.align(Alignment.TopEnd).padding(end = 9.dp, top = 3.dp)) {
                        Box(
                            modifier = Modifier.size(29.dp)
                                .background(Color(0xFF061B3D).copy(alpha = .72f), CircleShape)
                                .border(.8.dp, cyan.copy(alpha = .8f), CircleShape)
                                .clickable { showMenu = true },
                            contentAlignment = Alignment.Center
                        ) {
                            Text("☰", fontSize = 16.sp, color = Color.White)
                        }
                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                            DropdownMenuItem(text = { Text("Home") }, onClick = { selected = 0; showMenu = false })
                            DropdownMenuItem(text = { Text("Scanner de Pokémon") }, onClick = { selected = 8; showMenu = false })
                            DropdownMenuItem(text = { Text("Scanner de raides") }, onClick = { selected = 3; showMenu = false })
                            DropdownMenuItem(text = { Text("Sobre · v0.0.2") }, onClick = { selected = 10; showMenu = false })
                        }
                    }
                }
                // Each original menu icon is an actual interactive control. Active glow moves with selection.
                NavigationBarPoke(screenWidth, selected, onSelect = { selected = it })
                Box(Modifier.fillMaxWidth().height(8.dp).background(Brush.verticalGradient(
                    listOf(Color(0xFF054E91).copy(alpha = .50f), Color.Transparent)
                )))
                when (selectedModule.screen) {
                    Screen.HOME -> Spacer(Modifier.weight(1f))
                    Screen.SCANNER_POKEMON -> ScannerScreen(raid = false, modifier = Modifier.weight(1f))
                    Screen.SCANNER_RAID -> ScannerScreen(raid = true, modifier = Modifier.weight(1f))
                    Screen.OTHER -> Box(Modifier.weight(1f).padding(top = 12.dp), contentAlignment = Alignment.TopCenter) {
                        FrostedPanel(Modifier.fillMaxWidth(.90f)) {
                            Text(selectedModule.title, color = ice, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(8.dp))
                            Text("Módulo previsto no Arquivo Mestre PokeGoBR. Nesta versão, o Scanner de Pokémon e Raides já permite analisar capturas de tela.", color = ice.copy(alpha = .85f), fontSize = 13.sp)
                            Spacer(Modifier.height(12.dp))
                            OutlinedButton(onClick = { selected = 8 }) { Text("Abrir Scanner") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NavigationBarPoke(width: Dp, selected: Int, onSelect: (Int) -> Unit) {
    val iconWidth = ((width - 13.dp) / 11f).coerceAtMost(42.dp)
    Row(
        modifier = Modifier.fillMaxWidth().background(Color(0xFF061D3C).copy(alpha = .62f))
            .padding(horizontal = 6.dp, vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        modules.forEachIndexed { index, entry ->
            val active = selected == index
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier.size(iconWidth)
                        .shadow(if (active) 8.dp else 0.dp, CircleShape, ambientColor = cyan, spotColor = cyan)
                        .clip(CircleShape)
                        .background(if (active) Color(0xFF1DD9FF).copy(alpha = .34f) else Color.Transparent)
                        .border(if (active) 1.3.dp else .5.dp, if (active) cyan else Color.White.copy(alpha = .18f), CircleShape)
                        .clickable { onSelect(index) },
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(entry.drawable),
                        contentDescription = entry.title,
                        modifier = Modifier.fillMaxSize(.91f),
                        contentScale = ContentScale.Fit
                    )
                }
                Spacer(Modifier.height(3.dp))
                Box(Modifier.width(iconWidth * .64f).height(2.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (active) cyan else Color.Transparent))
            }
        }
    }
}

@Composable
private fun FrostedPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier.clip(RoundedCornerShape(17.dp))
            .background(Color(0xFF071B38).copy(alpha = .89f))
            .border(.8.dp, Color.White.copy(alpha = .22f), RoundedCornerShape(17.dp))
            .padding(14.dp),
        content = content
    )
}

@Composable
private fun ScannerScreen(raid: Boolean, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val recognizer = remember { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    DisposableEffect(recognizer) { onDispose { recognizer.close() } }
    var scanning by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf("") }
    var rawText by remember { mutableStateOf("") }
    var pokemonName by rememberSaveable { mutableStateOf("") }
    var pc by rememberSaveable { mutableStateOf("") }
    var ps by rememberSaveable { mutableStateOf("") }
    var atk by rememberSaveable { mutableIntStateOf(15) }
    var def by rememberSaveable { mutableIntStateOf(15) }
    var sta by rememberSaveable { mutableIntStateOf(15) }
    var savedCount by remember { mutableIntStateOf(0) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scanning = true
            errorText = ""
            try {
                val image = InputImage.fromFilePath(context, uri)
                recognizer.process(image)
                    .addOnSuccessListener { recognized ->
                        rawText = recognized.text
                        val info = ScreenshotParser.parse(recognized.text)
                        pc = info.cp?.toString() ?: pc
                        ps = info.hp?.toString() ?: ps
                        if (!info.candidateName.isNullOrBlank() && pokemonName.isBlank()) pokemonName = info.candidateName
                        scanning = false
                        if (rawText.isBlank()) errorText = "Não encontrei texto legível. Use uma captura mais nítida ou preencha os dados manualmente."
                    }.addOnFailureListener { exception ->
                        scanning = false
                        errorText = "Falha na leitura: ${exception.localizedMessage ?: "erro desconhecido"}"
                    }
            } catch (exception: Exception) {
                scanning = false
                errorText = "Não foi possível abrir a imagem: ${exception.localizedMessage ?: "arquivo inválido"}"
            }
        }
    }

    Column(
        modifier = modifier.fillMaxWidth().verticalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        FrostedPanel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (raid) "Scanner de Raides" else "Scanner de Pokémon", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("ALFA · 0.0.2", fontSize = 10.sp, color = cyan)
            }
            Spacer(Modifier.height(5.dp))
            Text(if (raid)
                "Selecione uma captura de raide. O OCR extrai o texto para revisão; reconhecimento do chefe e lobby chegarão nas próximas versões."
            else
                "Selecione uma captura do Pokémon. O scanner tenta reconhecer PC e PS; confirme os valores para obter uma análise de IV confiável.",
                color = ice.copy(alpha = .83f), fontSize = 12.sp, lineHeight = 17.sp
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = { picker.launch("image/*") }, enabled = !scanning, modifier = Modifier.fillMaxWidth()) {
                Text(if (scanning) "Lendo a imagem..." else "Selecionar captura da galeria")
            }
            if (scanning) {
                Spacer(Modifier.height(5.dp))
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            if (errorText.isNotBlank()) {
                Spacer(Modifier.height(7.dp))
                Text(errorText, color = Color(0xFFFFC4BE), fontSize = 12.sp)
            }
        }
        if (rawText.isNotBlank()) {
            FrostedPanel(Modifier.fillMaxWidth()) {
                Text("Texto reconhecido (OCR)", color = cyan, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Spacer(Modifier.height(6.dp))
                Text(rawText.take(3000), color = ice, fontSize = 12.sp, lineHeight = 17.sp)
            }
        }
        if (!raid) {
            FrostedPanel(Modifier.fillMaxWidth()) {
                Text("Conferir identificação", fontWeight = FontWeight.Bold, color = ice)
                Spacer(Modifier.height(5.dp))
                OutlinedTextField(value = pokemonName, onValueChange = { pokemonName = it.take(65) }, label = { Text("Nome do Pokémon") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = pc, onValueChange = { pc = it.filter(Char::isDigit).take(5) }, label = { Text("PC") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = ps, onValueChange = { ps = it.filter(Char::isDigit).take(5) }, label = { Text("PS") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Text("IV da avaliação do jogo (0 a 15)", color = ice, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                IvSelector("Ataque", atk) { atk = it }
                IvSelector("Defesa", def) { def = it }
                IvSelector("PS", sta) { sta = it }
                val score = atk + def + sta
                val pct = (100.0 * score / 45.0)
                val stars = when { score == 45 -> "4★"; score >= 37 -> "3★"; score >= 30 -> "2★"; score >= 23 -> "1★"; else -> "0★" }
                Text("IV: ${"%.1f".format(java.util.Locale.US, pct)}% · $stars · $atk/$def/$sta", color = cyan, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = {
                    saveLocalScan(context, pokemonName, pc, ps, atk, def, sta)
                    savedCount += 1
                }, modifier = Modifier.fillMaxWidth()) { Text("Salvar avaliação no aparelho") }
                Text("Atenção: o resultado de IV acima depende dos valores preenchidos. Esta versão não interpreta automaticamente as barras da avaliação.", color = ice.copy(alpha = .7f), fontSize = 10.sp)
            }
            val history = remember(savedCount) { readLocalScanHistory(context) }
            if (history.isNotEmpty()) {
                FrostedPanel(Modifier.fillMaxWidth()) {
                    Text("Últimas avaliações locais", color = cyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    history.take(5).forEach { Text(it, fontSize = 12.sp, color = ice) }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun IvSelector(title: String, value: Int, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text(title, modifier = Modifier.width(54.dp), fontSize = 12.sp, color = ice)
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.roundToInt().coerceIn(0, 15)) },
            valueRange = 0f..15f,
            steps = 14,
            modifier = Modifier.weight(1f).height(38.dp)
        )
        Text(value.toString(), modifier = Modifier.width(25.dp), textAlign = TextAlign.End, fontWeight = FontWeight.Bold, color = cyan)
    }
}

private fun saveLocalScan(context: Context, name: String, cp: String, hp: String, atk: Int, def: Int, sta: Int) {
    val prefs = context.getSharedPreferences("pokegobr_scans", Context.MODE_PRIVATE)
    val old = runCatching { JSONArray(prefs.getString("items", "[]")) }.getOrDefault(JSONArray())
    val output = JSONArray()
    output.put(JSONObject().put("name", name.ifBlank { "Pokémon" }).put("cp", cp).put("hp", hp)
        .put("iv", "$atk/$def/$sta").put("createdAt", System.currentTimeMillis()))
    for (index in 0 until minOf(9, old.length())) output.put(old.optJSONObject(index))
    prefs.edit().putString("items", output.toString()).apply()
}

private fun readLocalScanHistory(context: Context): List<String> {
    val prefs = context.getSharedPreferences("pokegobr_scans", Context.MODE_PRIVATE)
    val array = runCatching { JSONArray(prefs.getString("items", "[]")) }.getOrDefault(JSONArray())
    return (0 until minOf(10, array.length())).mapNotNull { index ->
        array.optJSONObject(index)?.let { obj ->
            "${obj.optString("name")} · PC ${obj.optString("cp", "—")} · IV ${obj.optString("iv")}"
        }
    }
}
