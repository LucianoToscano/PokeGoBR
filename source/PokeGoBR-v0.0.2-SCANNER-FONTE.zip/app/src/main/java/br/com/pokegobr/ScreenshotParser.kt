package br.com.pokegobr

/** Heuristics only. OCR cannot infer IV from CP or HP without verified appraisal bars. */
internal data class ScanFields(val cp: Int?, val hp: Int?, val candidateName: String?)

internal object ScreenshotParser {
    private val cpPrefixes = listOf(
        Regex("(?i)\\b(?:PC|CP)\\s*[:.]?\\s*(\\d{1,5})\\b"),
        Regex("(?i)\\b(\\d{1,5})\\s*(?:PC|CP)\\b")
    )
    private val hpPrefixes = listOf(
        Regex("(?i)\\b(?:PS|HP)\\s*[:.]?\\s*(\\d{1,5})\\b"),
        Regex("(?i)\\b(\\d{1,5})\\s*/\\s*\\d{1,5}\\s*(?:PS|HP)\\b")
    )
    fun parse(raw: String): ScanFields {
        val compact = raw.replace('Ｏ','O').replace('Ｐ','P')
        val cp = cpPrefixes.firstNotNullOfOrNull { it.find(compact)?.groupValues?.getOrNull(1)?.toIntOrNull() }
        val hp = hpPrefixes.firstNotNullOfOrNull { it.find(compact)?.groupValues?.getOrNull(1)?.toIntOrNull() }
        val candidates = compact.lines().map { it.trim() }.filter { line ->
            line.length in 3..28 && line.matches(Regex("[\\p{L} .'-]+")) &&
            !line.contains(Regex("(?i)\\b(?:POKEMON|POKÉMON|AVALIAR|AVALIAÇÃO|POWER UP|PODER|RAIDE|ITENS|CAPTURAR|PC|CP|PS|HP)\\b"))
        }
        // A weak hint, intentionally editable by the user.
        return ScanFields(cp, hp, candidates.firstOrNull())
    }
}
